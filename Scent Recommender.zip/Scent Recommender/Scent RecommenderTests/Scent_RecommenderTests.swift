//
//  Scent_RecommenderTests.swift
//  Scent RecommenderTests
//
//  Created by Lin Christine on 14/5/2025.
//

import Testing
@testable import Scent_Recommender

struct Scent_RecommenderTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
